

```python
# Dependencies
import pandas as pd
import matplotlib.pyplot as plt
from scipy import stats
import numpy as np
from scipy.stats import linregress
from sklearn.metrics import r2_score
```


```python
# read in excel file
file_2015 = 'happiness_data/2015.csv'
file_2016 = 'happiness_data/2016.csv'
file_2017 = 'happiness_data/2017.csv'

happiness_data_2015 = pd.read_csv(file_2015)
happiness_data_2016 = pd.read_csv(file_2016)
happiness_data_2017 = pd.read_csv(file_2017)

#add year column
happiness_data_2015['Year']= 2015
happiness_data_2016['Year']= 2016
happiness_data_2017['Year']= 2017

#get ready to concatenate our data together
list_data = [happiness_data_2015, happiness_data_2016, happiness_data_2017]


# happiness_data = pd.concat(list_data)

# happiness_data.head()

#match column names in all three data files
happiness_data_2017 = happiness_data_2017.rename(columns={'Happiness.Rank': 'Happiness Rank', 
                                      'Happiness.Score': 'Happiness Score',
                                      'Economy..GDP.per.Capita.' : 'Economy (GDP per Capita)',
                                      'Health..Life.Expectancy.' : 'Health (Life Expectancy)',
                                      'Trust..Government.Corruption.' : 'Trust (Government Corruption)', 
                                      'Dystopia.Residual' : 'Dystopia Residual'})

happiness_data_2015 = happiness_data_2015[['Country', 'Region', 'Happiness Rank', 'Happiness Score', 
                                          'Economy (GDP per Capita)', 'Family', 'Health (Life Expectancy)', 
                                          'Freedom', 'Trust (Government Corruption)','Generosity', 
                                          'Dystopia Residual', 'Year']]
happiness_data_2016 = happiness_data_2016[['Country', 'Region', 'Happiness Rank', 'Happiness Score', 
                                          'Economy (GDP per Capita)', 'Family', 'Health (Life Expectancy)', 
                                          'Freedom', 'Trust (Government Corruption)','Generosity', 
                                          'Dystopia Residual', 'Year']]
happiness_data_2017 = happiness_data_2017[['Country', 'Happiness Rank', 'Happiness Score', 
                                          'Economy (GDP per Capita)', 'Family', 'Health (Life Expectancy)', 
                                          'Freedom', 'Trust (Government Corruption)','Generosity', 
                                          'Dystopia Residual', 'Year']]
```


```python
#adding region column to 2017 data, cleaning up country/region names
country_region = {}

for i,row in happiness_data_2015.iterrows():
    country_region.update({row['Country']:row['Region']})
for i,row in happiness_data_2016.iterrows():
    country_region.update({row['Country']:row['Region']})
   
happiness_data_2017['Region'] = ''

try:
    for i, row in happiness_data_2017.iterrows():
        country = row['Country']
    if country == 'Taiwan Province of China':
        happiness_data_2017.at[i,'Country'] = 'Taiwan'
        happiness_data_2017.at[i,'Region'] = 'Eastern Asia'
    elif country == 'Belize':
        happiness_data_2017.at[i,'Region'] = 'Latin America and Caribbean'
    elif country == 'Hong Kong S.A.R., China':
        happiness_data_2017.at[i,'Region'] = 'Eastern Asia'
    elif country == 'Somalia':
        happiness_data_2017.at[i,'Region'] = 'Sub-Saharan Africa'
    else:
        happiness_data_2017.at[i,'Region'] = country_region[country]
except KeyError:
        print(f"Cannot find {country}")
        pass
   
#rearranging columns for cleaniness
happiness_data_2017 = happiness_data_2017[['Year','Country', 'Region','Happiness Rank', 'Happiness Score', 
                                          'Economy (GDP per Capita)', 'Family', 'Health (Life Expectancy)', 
                                          'Freedom', 'Trust (Government Corruption)','Generosity', 
                                          'Dystopia Residual']]
happiness_data_2015 = happiness_data_2015[['Year','Country', 'Region','Happiness Rank', 'Happiness Score', 
                                          'Economy (GDP per Capita)', 'Family', 'Health (Life Expectancy)', 
                                          'Freedom', 'Trust (Government Corruption)','Generosity', 
                                          'Dystopia Residual']]
happiness_data_2016 = happiness_data_2016[['Year','Country', 'Region','Happiness Rank', 'Happiness Score', 
                                          'Economy (GDP per Capita)', 'Family', 'Health (Life Expectancy)', 
                                          'Freedom', 'Trust (Government Corruption)','Generosity', 
                                          'Dystopia Residual']]
```

# Freedom's Effect on World Happiness


```python
data_2015 = happiness_data_2015[['Year','Country', 'Region','Happiness Rank', 'Happiness Score',
                                          'Freedom', 'Trust (Government Corruption)', 'Generosity','Economy (GDP per Capita)']]
data_2016 = happiness_data_2016[['Year','Country', 'Region','Happiness Rank', 'Happiness Score',
                                          'Freedom', 'Trust (Government Corruption)', 'Generosity','Economy (GDP per Capita)']]
data_2017 = happiness_data_2017[['Year','Country', 'Region','Happiness Rank', 'Happiness Score',
                                          'Freedom', 'Trust (Government Corruption)', 'Generosity', 'Economy (GDP per Capita)']]
```


```python
happiness_2015 = data_2015['Happiness Score']
happiness_2016 = data_2016['Happiness Score']
happiness_2017 = data_2017['Happiness Score']

freedom_2015 = data_2015['Freedom']
freedom_2016 = data_2016['Freedom']
freedom_2017 = data_2017['Freedom']

gdp_2015 = data_2015['Economy (GDP per Capita)']
gdp_2016 = data_2016['Economy (GDP per Capita)']
gdp_2017 = data_2017['Economy (GDP per Capita)']

(slope, intercept, _, _, _) = linregress(happiness_2015, freedom_2015)
fit = slope * happiness_2015 + intercept

fig, ax = plt.subplots()

fig.suptitle("2015 Happiness vs Freedom Score")
ax.set_xlabel("Freedom Score")
ax.set_ylabel("Happiness Score")

ax.plot(happiness_2015, freedom_2015, linewidth=0, marker='o', color = "red")
ax.plot(happiness_2015, fit, 'red')
```




    [<matplotlib.lines.Line2D at 0x19c4d2bfe48>]




![png](output_5_1.png)



```python
(slope, intercept, _, _, _) = linregress(happiness_2016, freedom_2016)
fit = slope * happiness_2016 + intercept

fig, ax = plt.subplots()

fig.suptitle("2016 Happiness vs Freedom Score")
ax.set_xlabel("Freedom Score")
ax.set_ylabel("Happiness Score")

ax.plot(happiness_2016, freedom_2016, linewidth=0, marker='o', color = "orange")
ax.plot(happiness_2016, fit, 'orange')
```




    [<matplotlib.lines.Line2D at 0x19c4d364b70>]




![png](output_6_1.png)



```python
(slope, intercept, _, _, _) = linregress(happiness_2017, freedom_2017)
fit = slope * happiness_2017 + intercept

fig, ax = plt.subplots()

fig.suptitle("2017 Happiness vs Freedom Score")
ax.set_xlabel("Freedom Score")
ax.set_ylabel("Happiness Score")

ax.plot(happiness_2017, freedom_2017, linewidth=0, marker='o', color = "red")
ax.plot(happiness_2017, fit, 'red')
```




    [<matplotlib.lines.Line2D at 0x19c4d3d22b0>]




![png](output_7_1.png)



```python
freedom_2015_r = r2_score(happiness_2015, freedom_2015)
freedom_2016_r = r2_score(happiness_2016, freedom_2016)
freedom_2017_r = r2_score(happiness_2017, freedom_2017)
print(freedom_2015_r)
print(freedom_2016_r)
print(freedom_2017_r)
```

    -18.654156704149283
    -19.261547962852593
    -19.100963428130775
    

# Trust in Government's Effect on World Happiness


```python
trust_2015 = data_2015['Trust (Government Corruption)']
trust_2016 = data_2016['Trust (Government Corruption)']
trust_2017 = data_2017['Trust (Government Corruption)']
```


```python
(slope, intercept, _, _, _) = linregress(happiness_2015, trust_2015)
fit = slope * happiness_2015 + intercept

fig, ax = plt.subplots()

fig.suptitle("2015 Happiness vs Trust (Government Corruption)")
ax.set_xlabel("Trust Score")
ax.set_ylabel("Happiness Score")

ax.plot(happiness_2015, trust_2015, linewidth=0, marker='o', color = "red")
ax.plot(happiness_2015, fit, 'red')
```




    [<matplotlib.lines.Line2D at 0x19c4d4333c8>]




![png](output_11_1.png)



```python
(slope, intercept, _, _, _) = linregress(happiness_2016, trust_2016)
fit = slope * happiness_2016 + intercept

fig, ax = plt.subplots()

fig.suptitle("2016 Happiness vs Trust (Government Corruption)")
ax.set_xlabel("Trust Score")
ax.set_ylabel("Happiness Score")

ax.plot(happiness_2016, trust_2016, linewidth=0, marker='o', color = "blue")
ax.plot(happiness_2016, fit, 'blue')
```




    [<matplotlib.lines.Line2D at 0x19c4d494358>]




![png](output_12_1.png)



```python
(slope, intercept, _, _, _) = linregress(happiness_2017, trust_2017)
fit = slope * happiness_2017 + intercept

fig, ax = plt.subplots()

fig.suptitle("2017 Happiness vs Trust (Government Corruption)")
ax.set_xlabel("Trust Score")
ax.set_ylabel("Happiness Score")

ax.plot(happiness_2017, trust_2017, linewidth=0, marker='o', color = "green")
ax.plot(happiness_2017, fit, 'green')
```




    [<matplotlib.lines.Line2D at 0x19c4d4f26a0>]




![png](output_13_1.png)



```python
trust_2015_r = r2_score(happiness_2015, trust_2015)
trust_2016_r = r2_score(happiness_2016, trust_2016)
trust_2017_r = r2_score(happiness_2017, trust_2017)
print(trust_2015_r)
print(trust_2016_r)
print(trust_2017_r)
```

    -20.94297100979558
    -21.169054311556174
    -21.451922169771514
    

# Generosity's Effect on World Happiness


```python
generosity_2015 = data_2015['Generosity']
generosity_2016 = data_2016['Generosity']
generosity_2017 = data_2017['Generosity']

(slope, intercept, _, _, _) = linregress(happiness_2015, generosity_2015)
fit = slope * happiness_2015 + intercept

fig, ax = plt.subplots()

fig.suptitle("2015 Happiness vs Generosity")
ax.set_xlabel("Generosity Score")
ax.set_ylabel("Happiness Score")

ax.plot(happiness_2015, generosity_2015, linewidth=0, marker='o', color = "red")
ax.plot(happiness_2015, fit, 'red')
```




    [<matplotlib.lines.Line2D at 0x19c4d54ca20>]




![png](output_16_1.png)



```python
(slope, intercept, _, _, _) = linregress(happiness_2016, generosity_2016)
fit = slope * happiness_2016 + intercept

fig, ax = plt.subplots()

fig.suptitle("2016 Happiness vs Generosity")
ax.set_xlabel("Generosity Score")
ax.set_ylabel("Happiness Score")

ax.plot(happiness_2016, generosity_2016, linewidth=0, marker='o', color = "blue")
ax.plot(happiness_2016, fit, 'blue')
```




    [<matplotlib.lines.Line2D at 0x19c4d5b9048>]




![png](output_17_1.png)



```python
(slope, intercept, _, _, _) = linregress(happiness_2017, generosity_2017)
fit = slope * happiness_2017 + intercept

fig, ax = plt.subplots()

fig.suptitle("2017 Happiness vs Generosity")
ax.set_xlabel("Generosity Score")
ax.set_ylabel("Happiness Score")

ax.plot(happiness_2017, generosity_2017, linewidth=0, marker='o', color = "red")
ax.plot(happiness_2017, fit, 'red')
```




    [<matplotlib.lines.Line2D at 0x19c4d60dda0>]




![png](output_18_1.png)



```python
genero_2015_r = r2_score(happiness_2015, generosity_2015)
genero_2016_r = r2_score(happiness_2016, generosity_2016)
genero_2017_r = r2_score(happiness_2017, generosity_2017)
print(genero_2015_r)
print(genero_2016_r)
print(genero_2017_r)
```

    -20.23988435516908
    -20.372802897097994
    -20.491839923684566
    


```python
# Attempt to find correlation within certain regions.
# region_data_2015 = data_2015.loc[data_2015['Region'] == "Western Europe"]
# region_data_2016 = data_2016.loc[data_2016['Region'] == "Western Europe"]
# region_data_2017 = data_2017.loc[data_2017['Region'] == "Western Europe"]
```


```python
# region_happiness_2015 = region_data_2015['Happiness Score']
# region_freedom_2015 = region_data_2015['Freedom']

# (slope, intercept, _, _, _) = linregress(region_happiness_2015, region_freedom_2015)
# fit = slope * region_happiness_2015 + intercept

# fig, ax = plt.subplots()

# fig.suptitle("2015 Western Europe Happiness vs Freedom")
# ax.set_xlabel("Freedom Score")
# ax.set_ylabel("Happiness Score")

# ax.plot(region_happiness_2015, region_freedom_2015, linewidth=0, marker='o', color = "red")
# ax.plot(region_happiness_2015, fit, 'red')
```


```python
# region_happiness_2016 = region_data_2016['Happiness Score']
# region_freedom_2016 = region_data_2016['Freedom']

# (slope, intercept, _, _, _) = linregress(region_happiness_2016, region_freedom_2016)
# fit = slope * region_happiness_2016 + intercept

# fig, ax = plt.subplots()

# fig.suptitle("2016 Western Europe Happiness vs Freedom")
# ax.set_xlabel("Freedom Score")
# ax.set_ylabel("Happiness Score")

# ax.plot(region_happiness_2016, region_freedom_2016, linewidth=0, marker='o', color = "blue")
# ax.plot(region_happiness_2016, fit, 'blue')
```

# Economoy's Effect on World Happiness


```python
(slope, intercept, _, _, _) = linregress(happiness_2015, gdp_2015)
fit = slope * happiness_2015 + intercept

fig, ax = plt.subplots()

fig.suptitle("2015 Happiness vs Economy (GDP per Capita)")
ax.set_xlabel("GDP per Capita")
ax.set_ylabel("Happiness Score")

ax.plot(happiness_2015, gdp_2015, linewidth=0, marker='o', color = "orange")
ax.plot(happiness_2015, fit, 'orange')
```




    [<matplotlib.lines.Line2D at 0x19c4d66f6d8>]




![png](output_24_1.png)



```python
(slope, intercept, _, _, _) = linregress(happiness_2016, gdp_2016)
fit = slope * happiness_2016 + intercept

fig, ax = plt.subplots()

fig.suptitle("2016 Happiness vs Economy (GDP per Capita)")
ax.set_xlabel("GDP per Capita")
ax.set_ylabel("Happiness Score")

ax.plot(happiness_2016, gdp_2016, linewidth=0, marker='o', color = "red")
ax.plot(happiness_2016, fit, 'red')
```




    [<matplotlib.lines.Line2D at 0x19c4d6ccdd8>]




![png](output_25_1.png)



```python
(slope, intercept, _, _, _) = linregress(happiness_2017, gdp_2017)
fit = slope * happiness_2017 + intercept

fig, ax = plt.subplots()

fig.suptitle("2017 Happiness vs Economy (GDP per Capita)")
ax.set_xlabel("GDP per Capita")
ax.set_ylabel("Happiness Score")

ax.plot(happiness_2017, gdp_2017, linewidth=0, marker='o', color = "orange")
ax.plot(happiness_2017, fit, 'orange')
```




    [<matplotlib.lines.Line2D at 0x19c4d729eb8>]




![png](output_26_1.png)



```python
gdp_2015_r = r2_score(happiness_2015, gdp_2015)
gdp_2016_r = r2_score(happiness_2016, gdp_2016)
gdp_2017_r = r2_score(happiness_2017, gdp_2017)
print(gdp_2015_r)
print(gdp_2016_r)
print(gdp_2017_r)
```

    -15.323224526628952
    -14.700776200283762
    -14.549192934825168
    

# Analysis to study impact of internet usage on happiness

Popular thought and policy seems to drive that internet usage leads to development and therefore happiness should increase amonmgst the population. A study of the data however, gives some interesting insights. Effect of Internet usage is subjective from country to country. While in some countries, it shows a positive relationship, in some it is neutral and in some cases even negative. We picked some example countries to highlight this. 1) In the first case, countries like Aghanistan and to a certain extent China, show a positive co-relation. These could be attributed to the opening up effect that internet has to these countries as they were isolated earlier. The internet may also be an enabling factor to improve economic aspects. 2) In the second case of little or no relationship seems to be for developed countries, like Japan, where a high majority of population has internet access, and the society is fairly homogenous. Given this, it looks like there is a point beyond which further internet usage increases have no signifcant impact. 3) The third case where we see decreasing happiness with internet usage, is rather surprising. But it seems to be the case in some rapidly developing countries where internet and technology have played a significant impact. On further research and study, this may be attributed to the significant societal divisions that exist, like income or social divide. While many people have access to the internet and use it, other factors stop them from being able to derive benefit from it. And social media also tends to have a negative impact in such societies. In these cases, internet may actually be having a negative impact on people's happiness.


```python
#see effect of internet usage on happiness score
happiness_data_historical = pd.read_csv('happiness_data/hapinnesscorehistorical.csv')
print(happiness_data_historical.dtypes)
happiness_data_historical.head()
```

    country         object
    year             int64
    Life Ladder    float64
    dtype: object
    




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>country</th>
      <th>year</th>
      <th>Life Ladder</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>Afghanistan</td>
      <td>2008</td>
      <td>3.723590</td>
    </tr>
    <tr>
      <th>1</th>
      <td>Afghanistan</td>
      <td>2009</td>
      <td>4.401778</td>
    </tr>
    <tr>
      <th>2</th>
      <td>Afghanistan</td>
      <td>2010</td>
      <td>4.758381</td>
    </tr>
    <tr>
      <th>3</th>
      <td>Afghanistan</td>
      <td>2011</td>
      <td>3.831719</td>
    </tr>
    <tr>
      <th>4</th>
      <td>Afghanistan</td>
      <td>2012</td>
      <td>3.782938</td>
    </tr>
  </tbody>
</table>
</div>




```python
internet_usage_historical = pd.read_csv('happiness_data/internetusage.csv', encoding='iso-8859-1')
internet_usage_historical.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Country Name</th>
      <th>Country Code</th>
      <th>2008</th>
      <th>2009</th>
      <th>2010</th>
      <th>2011</th>
      <th>2012</th>
      <th>2013</th>
      <th>2014</th>
      <th>2015</th>
      <th>2016</th>
      <th>2017</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>Aruba</td>
      <td>ABW</td>
      <td>52.00</td>
      <td>58.00</td>
      <td>62.0</td>
      <td>69.0</td>
      <td>74.000000</td>
      <td>78.9</td>
      <td>83.78</td>
      <td>88.661227</td>
      <td>93.542454</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>1</th>
      <td>Afghanistan</td>
      <td>AFG</td>
      <td>1.84</td>
      <td>3.55</td>
      <td>4.0</td>
      <td>5.0</td>
      <td>5.454545</td>
      <td>5.9</td>
      <td>7.00</td>
      <td>8.260000</td>
      <td>10.595726</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>2</th>
      <td>Angola</td>
      <td>AGO</td>
      <td>1.90</td>
      <td>2.30</td>
      <td>2.8</td>
      <td>3.1</td>
      <td>6.500000</td>
      <td>8.9</td>
      <td>10.20</td>
      <td>12.400000</td>
      <td>13.000000</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>3</th>
      <td>Albania</td>
      <td>ALB</td>
      <td>23.86</td>
      <td>41.20</td>
      <td>45.0</td>
      <td>49.0</td>
      <td>54.655959</td>
      <td>57.2</td>
      <td>60.10</td>
      <td>63.252933</td>
      <td>66.363445</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>4</th>
      <td>Andorra</td>
      <td>AND</td>
      <td>70.04</td>
      <td>78.53</td>
      <td>81.0</td>
      <td>81.0</td>
      <td>86.434425</td>
      <td>94.0</td>
      <td>95.90</td>
      <td>96.910000</td>
      <td>97.930637</td>
      <td>NaN</td>
    </tr>
  </tbody>
</table>
</div>




```python
## plot happiness and internet usage by year for 
country = "India"
years = np.arange(2008,2017,1)

happiness_scores = []
internet_usage = []

for yr in years :
    hp_score = happiness_data_historical[(happiness_data_historical['country'] == country) & (happiness_data_historical['year']==yr)]
    happiness_scores.append(hp_score.iloc[0]['Life Ladder'])
    
    int_use = internet_usage_historical[internet_usage_historical['Country Name']== country]
    internet_usage.append((int_use.iloc[0][str(yr)])/10)

#print(happiness_scores)
#print(internet_usage)
hp_handle, = plt.plot(years, happiness_scores, color="green", label='Happiness')
int_handle, = plt.plot(years, internet_usage, color="blue", label='Internet Usage')
plt.title(f"Happiness vs Internet usage trend for {country}")
plt.xlabel("Year")
plt.ylabel("Happiness/Internet Usage")
plt.legend(handles=[hp_handle, int_handle], loc="upper right")
plt.savefig(f"HapInt_{country}.png")
plt.show()

hap_origin = happiness_scores[0]
hap_last = happiness_scores[len(happiness_scores) - 1]
hap_change = (hap_last - hap_origin)/hap_origin*100

int_origin = internet_usage[0]

```


![png](output_32_0.png)



```python
## plot happiness and internet usage by year for 
country = "Afghanistan"
years = np.arange(2008,2017,1)

happiness_scores = []
internet_usage = []

for yr in years :
    hp_score = happiness_data_historical[(happiness_data_historical['country'] == country) & (happiness_data_historical['year']==yr)]
    hp_score.reindex()
    happiness_scores.append(hp_score.iloc[0]['Life Ladder'])
    
    int_use = internet_usage_historical[internet_usage_historical['Country Name']== country]
    internet_usage.append((int_use.iloc[0][str(yr)])/10)

#print(happiness_scores)
#print(internet_usage)
hp_handle, = plt.plot(years, happiness_scores, color="green", label='Happiness')
int_handle, = plt.plot(years, internet_usage, color="blue", label='Internet Usage')
plt.title(f"Happiness vs Internet usage trend for {country}")
plt.xlabel("Year")
plt.ylabel("Happiness/Internet Usage")
plt.legend(handles=[hp_handle, int_handle])
plt.savefig(f"HapInt_{country}.png")
plt.show()
```


![png](output_33_0.png)



```python
## plot happiness and internet usage by year for 
country = "Japan"
years = np.arange(2008,2017,1)

happiness_scores = []
internet_usage = []

for yr in years :
    hp_score = happiness_data_historical[(happiness_data_historical['country'] == country) & (happiness_data_historical['year']==yr)]
    hp_score.reindex()
    happiness_scores.append(hp_score.iloc[0]['Life Ladder'])
    
    int_use = internet_usage_historical[internet_usage_historical['Country Name']== country]
    internet_usage.append((int_use.iloc[0][str(yr)])/10)

#print(happiness_scores)
#print(internet_usage)
hp_handle, = plt.plot(years, happiness_scores, color="green", label='Happiness')
int_handle, = plt.plot(years, internet_usage, color="blue", label='Internet Usage')
plt.title(f"Happiness vs Internet usage trend for {country}")
plt.xlabel("Year")
plt.ylabel("Happiness/Internet Usage")
plt.legend(handles=[hp_handle, int_handle])
plt.savefig(f"HapInt_{country}.png")
plt.show()
```


![png](output_34_0.png)



```python
## plot happiness and internet usage by year for 
country = "China"
years = np.arange(2008,2017,1)

happiness_scores = []
internet_usage = []

for yr in years :
    hp_score = happiness_data_historical[(happiness_data_historical['country'] == country) & (happiness_data_historical['year']==yr)]
    hp_score.reindex()
    happiness_scores.append(hp_score.iloc[0]['Life Ladder'])
    
    int_use = internet_usage_historical[internet_usage_historical['Country Name']== country]
    internet_usage.append((int_use.iloc[0][str(yr)])/10)

#print(happiness_scores)
#print(internet_usage)
hp_handle, = plt.plot(years, happiness_scores, color="green", label='Happiness')
int_handle, = plt.plot(years, internet_usage, color="blue", label='Internet Usage')
plt.title(f"Happiness vs Internet usage trend for {country}")
plt.xlabel("Year")
plt.ylabel("Happiness/Internet Usage")
plt.legend(handles=[hp_handle, int_handle])
plt.savefig(f"HapInt_{country}.png")
plt.show()
```


![png](output_35_0.png)

